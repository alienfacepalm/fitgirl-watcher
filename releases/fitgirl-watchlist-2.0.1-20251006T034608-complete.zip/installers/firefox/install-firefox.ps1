# FitGirl Repacks Watchlist - Firefox Installer
# PowerShell Script

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "FitGirl Repacks Watchlist - Firefox" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This installer will help you install the FitGirl Repacks Watchlist extension." -ForegroundColor Green
Write-Host ""
Write-Host "Please follow these steps:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Open Firefox browser" -ForegroundColor White
Write-Host "2. Go to about:debugging" -ForegroundColor White
Write-Host "3. Click 'This Firefox' in the left sidebar" -ForegroundColor White
Write-Host "4. Click 'Load Temporary Add-on' button" -ForegroundColor White
Write-Host "5. Select the manifest.json file in this folder: $PSScriptRoot\manifest.json" -ForegroundColor White
Write-Host "6. The extension should now appear in your extensions list" -ForegroundColor White
Write-Host ""
Write-Host "Note: This is a temporary installation. The extension will be removed" -ForegroundColor Yellow
Write-Host "when you restart Firefox. For permanent installation, you need to" -ForegroundColor Yellow
Write-Host "sign the extension through Mozilla's process." -ForegroundColor Yellow
Write-Host ""
Write-Host "The extension will work on fitgirl-repacks.site" -ForegroundColor Green
Write-Host ""
Write-Host "Press Enter to open Firefox debugging page..." -ForegroundColor Yellow
Read-Host

try {
    Start-Process "firefox" -ArgumentList "about:debugging"
    Write-Host "Firefox debugging page opened!" -ForegroundColor Green
} catch {
    Write-Host "Could not open Firefox automatically. Please manually go to about:debugging" -ForegroundColor Red
}

Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "Press Enter to exit..." -ForegroundColor Yellow
Read-Host
