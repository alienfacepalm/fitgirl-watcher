#!/bin/bash

echo "========================================"
echo "FitGirl Repacks Watchlist - Firefox"
echo "========================================"
echo ""
echo "This installer will help you install the FitGirl Repacks Watchlist extension."
echo ""
echo "Please follow these steps:"
echo ""
echo "1. Open Firefox browser"
echo "2. Go to about:debugging"
echo "3. Click 'This Firefox' in the left sidebar"
echo "4. Click 'Load Temporary Add-on' button"
echo "5. Select the manifest.json file in this folder: $(pwd)/manifest.json"
echo "6. The extension should now appear in your extensions list"
echo ""
echo "Note: This is a temporary installation. The extension will be removed"
echo "when you restart Firefox. For permanent installation, you need to"
echo "sign the extension through Mozilla's process."
echo ""
echo "The extension will work on fitgirl-repacks.site"
echo ""
echo "Press Enter to open Firefox debugging page..."
read -r
echo "Opening Firefox debugging page..."

# Try to open Firefox debugging page
if command -v firefox &> /dev/null; then
    firefox about:debugging &
else
    echo "Firefox not found. Please manually open about:debugging"
fi

echo ""
echo "Installation complete!"
