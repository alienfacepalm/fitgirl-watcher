# FitGirl Repacks Watchlist - Installation Guide

## Quick Installation

### Chrome/Edge Users
1. **Run the installer:**
   - **Windows**: Double-click `install-chrome.bat` or `install-chrome.ps1`
   - **macOS/Linux**: Run `./install-chrome.sh` in terminal

2. **Follow the on-screen instructions** to load the extension

### Firefox Users
1. **Run the installer:**
   - **Windows**: Double-click `install-firefox.bat` or `install-firefox.ps1`
   - **macOS/Linux**: Run `./install-firefox.sh` in terminal

2. **Follow the on-screen instructions** to load the extension

## Manual Installation

### Chrome/Edge
1. Open Chrome/Edge and go to `chrome://extensions/` (or `edge://extensions/`)
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the `chrome/` folder from this installer package

### Firefox
1. Open Firefox and go to `about:debugging`
2. Click "This Firefox" in the left sidebar
3. Click "Load Temporary Add-on"
4. Select the `manifest.json` file from the `firefox/` folder

## Features

- 🎮 **Easy Watchlist Management**: Add games to your watchlist with a single click
- ⏰ **Smart Reminders**: Set custom reminder intervals (default: 7 days)
- 🔔 **Desktop Notifications**: Get notified when it's time to check your watchlist
- 📱 **Modern UI**: Clean, responsive interface that works on all devices
- 💾 **Data Export/Import**: Backup and restore your watchlist data

## Usage

1. Visit `fitgirl-repacks.site`
2. Look for the "Add to Watchlist" button (➕) next to game items
3. Click the button to add games to your watchlist
4. Click the extension icon to manage your watchlist and set reminders

## Support

For issues or questions, please visit: https://github.com/alienfacepalm/fitgirl-watcher

## Version

FitGirl Repacks Watchlist v1.0.0
