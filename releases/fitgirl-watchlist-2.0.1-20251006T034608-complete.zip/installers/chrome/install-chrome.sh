#!/bin/bash

echo "========================================"
echo "FitGirl Repacks Watchlist - Chrome/Edge"
echo "========================================"
echo ""
echo "This installer will help you install the FitGirl Repacks Watchlist extension."
echo ""
echo "Please follow these steps:"
echo ""
echo "1. Open Chrome or Edge browser"
echo "2. Go to chrome://extensions/ (or edge://extensions/ for Edge)"
echo "3. Enable 'Developer mode' (toggle in top right corner)"
echo "4. Click 'Load unpacked' button"
echo "5. Select this folder: $(pwd)"
echo "6. The extension should now appear in your extensions list"
echo ""
echo "The extension will work on fitgirl-repacks.site"
echo ""
echo "Press Enter to open Chrome extensions page..."
read -r
echo "Opening Chrome extensions page..."

# Try to open Chrome extensions page
if command -v google-chrome &> /dev/null; then
    google-chrome chrome://extensions/ &
elif command -v chromium-browser &> /dev/null; then
    chromium-browser chrome://extensions/ &
elif command -v chrome &> /dev/null; then
    chrome chrome://extensions/ &
else
    echo "Chrome not found. Please manually open chrome://extensions/"
fi

echo ""
echo "Installation complete!"
