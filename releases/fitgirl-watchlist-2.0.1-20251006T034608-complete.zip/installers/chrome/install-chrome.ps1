# FitGirl Repacks Watchlist - Chrome/Edge Installer
# PowerShell Script

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "FitGirl Repacks Watchlist - Chrome/Edge" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This installer will help you install the FitGirl Repacks Watchlist extension." -ForegroundColor Green
Write-Host ""
Write-Host "Please follow these steps:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Open Chrome or Edge browser" -ForegroundColor White
Write-Host "2. Go to chrome://extensions/ (or edge://extensions/ for Edge)" -ForegroundColor White
Write-Host "3. Enable 'Developer mode' (toggle in top right corner)" -ForegroundColor White
Write-Host "4. Click 'Load unpacked' button" -ForegroundColor White
Write-Host "5. Select this folder: $PSScriptRoot" -ForegroundColor White
Write-Host "6. The extension should now appear in your extensions list" -ForegroundColor White
Write-Host ""
Write-Host "The extension will work on fitgirl-repacks.site" -ForegroundColor Green
Write-Host ""
Write-Host "Press Enter to open Chrome extensions page..." -ForegroundColor Yellow
Read-Host

try {
    Start-Process "chrome://extensions/"
    Write-Host "Chrome extensions page opened!" -ForegroundColor Green
} catch {
    Write-Host "Could not open Chrome automatically. Please manually go to chrome://extensions/" -ForegroundColor Red
}

Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "Press Enter to exit..." -ForegroundColor Yellow
Read-Host
