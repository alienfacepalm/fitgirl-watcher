@echo off
echo ========================================
echo FitGirl Repacks Watchlist - Chrome/Edge
echo ========================================
echo.
echo This installer will help you install the FitGirl Repacks Watchlist extension.
echo.
echo Please follow these steps:
echo.
echo 1. Open Chrome or Edge browser
echo 2. Go to chrome://extensions/ (or edge://extensions/ for Edge)
echo 3. Enable "Developer mode" (toggle in top right corner)
echo 4. Click "Load unpacked" button
echo 5. Select this folder: %~dp0
echo 6. The extension should now appear in your extensions list
echo.
echo The extension will work on fitgirl-repacks.site
echo.
echo Press any key to open Chrome extensions page...
pause >nul
start chrome://extensions/
echo.
echo Installation complete! You can close this window.
pause
