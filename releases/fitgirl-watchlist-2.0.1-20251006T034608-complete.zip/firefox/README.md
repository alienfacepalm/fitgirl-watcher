# FitGirl Repacks Watchlist - Firefox Extension

## 🎮 About This Extension

A browser extension to create a watchlist for FitGirl repacks with reminder functionality

**Version:** 1.0.0  
**Author:** FitGirl Watchlist Team  
**Website:** https://github.com/alienfacepalm/fitgirl-watcher

## ✨ Features

- 🎯 **Easy Watchlist Management**: Add games to your watchlist with a single click
- ⏰ **Smart Reminders**: Set custom reminder intervals (default: 7 days)
- 🔔 **Desktop Notifications**: Get notified when it's time to check your watchlist
- 📱 **Modern UI**: Clean, responsive interface that works on all devices
- 💾 **Data Export/Import**: Backup and restore your watchlist data
- 🎯 **Smart Detection**: Automatically detects game items on fitgirl-repacks.site

## 🚀 Quick Installation

### Method 1: Load Temporary Add-on (Recommended)

1. **Open Firefox Debugging Page**
   - Go to `about:debugging`

2. **Select This Firefox**
   - Click "This Firefox" in the left sidebar

3. **Load the Extension**
   - Click "Load Temporary Add-on" button
   - Navigate to and select the `manifest.json` file in this folder
   - The extension should now appear in your add-ons list

4. **Pin the Extension** (Optional)
   - Click the puzzle piece icon in the toolbar
   - Find "FitGirl Repacks Watchlist"
   - Click the pin icon to keep it visible

### Method 2: Drag and Drop

1. **Open Debugging Page**
   - Go to `about:debugging`

2. **Select This Firefox**
   - Click "This Firefox" in the left sidebar

3. **Drag and Drop**
   - Simply drag the `manifest.json` file onto the debugging page
   - The extension will be automatically installed

## 📋 Step-by-Step Installation Guide

### Step 1: Prepare Firefox

1. Open Mozilla Firefox
2. Navigate to the debugging page by typing `about:debugging` in the address bar
3. Press Enter

### Step 2: Select This Firefox

1. In the left sidebar, click "This Firefox"
2. You should see options for loading temporary add-ons

### Step 3: Install the Extension

1. Click the "Load Temporary Add-on" button
2. Navigate to this folder and select the `manifest.json` file
3. Click "Open"
4. The extension should now appear in your add-ons list

### Step 4: Verify Installation

1. Look for "FitGirl Repacks Watchlist" in your add-ons list
2. Make sure it's enabled
3. You should see the extension icon in your browser toolbar

### Step 5: Test the Extension

1. Visit `https://fitgirl-repacks.site/`
2. You should see a purple top bar with "FitGirl Watchlist"
3. Look for "Add to Watchlist" buttons (➕) next to game items
4. Click the extension icon to open the popup and manage your watchlist

## ⚠️ Important Notes for Firefox

### Temporary Installation

- This is a **temporary installation**
- The extension will be removed when you restart Firefox
- For permanent installation, you need to sign the extension through Mozilla's process

### Permanent Installation (Advanced)

To make the installation permanent:

1. **Sign the Extension**
   - You need to submit the extension to Mozilla for signing
   - Visit: https://addons.mozilla.org/developers/
   - Follow Mozilla's submission process

2. **Alternative: Developer Mode**
   - Install Firefox Developer Edition
   - Use the same temporary installation method
   - Developer Edition allows unsigned extensions

## 🎯 How to Use

### Adding Games to Watchlist

1. Visit any page on `fitgirl-repacks.site`
2. Look for the "Add to Watchlist" button (➕) next to game items
3. Click the button to add the game to your watchlist
4. The button will change to "In Watchlist" (✅) to confirm

### Managing Your Watchlist

1. Click the extension icon in your browser toolbar
2. View all your watchlisted games
3. Use the search and filter options to find specific games
4. Click on any game to visit its page
5. Remove games from your watchlist as needed

### Setting Reminders

1. Open the extension popup
2. Go to the "Settings" tab
3. Adjust the reminder interval (default: 7 days)
4. Enable/disable desktop notifications
5. Your settings will be saved automatically

## 🔧 Troubleshooting

### Extension Not Appearing

- **Check Debugging Page**: Make sure you're on `about:debugging` and selected "This Firefox"
- **Check manifest.json**: Ensure you selected the correct manifest.json file
- **Refresh Page**: Reload the debugging page and try again

### Extension Not Working on FitGirl

- **Check URL**: Make sure you're on `fitgirl-repacks.site` (not the old domain)
- **Refresh Page**: Try refreshing the page after installing the extension
- **Check Permissions**: Ensure the extension has permission to access the site

### Icons Not Showing

- **Check Icon Files**: Make sure icon16.png, icon48.png, and icon128.png exist in the icons/ folder
- **File Names**: Icon files must be named exactly as specified
- **File Format**: Icons must be in PNG format

### Notifications Not Working

- **Browser Settings**: Check that notifications are enabled in Firefox settings
- **Extension Settings**: Make sure notifications are enabled in the extension settings
- **System Settings**: Ensure your operating system allows notifications from Firefox

### Data Not Saving

- **Storage Permissions**: The extension needs storage permissions to save your watchlist
- **Browser Storage**: Check if Firefox's storage is full or disabled
- **Private Mode**: The extension may not work properly in private browsing mode

## 📁 File Structure

```
FitGirl Repacks Watchlist/
├── manifest.json          # Extension configuration
├── background.js          # Background service worker
├── content.js            # Content script for FitGirl pages
├── popup.html            # Extension popup interface
├── popup.js              # Popup functionality
├── popup.css             # Popup styling
├── styles.css            # Content script styling
├── icons/                # Extension icons
│   ├── icon16.png        # 16x16 icon
│   ├── icon48.png        # 48x48 icon
│   └── icon128.png       # 128x128 icon
├── README.md             # This file
├── INSTALLATION.md       # Detailed installation guide
└── TROUBLESHOOTING.md    # Troubleshooting guide
```

## 🔄 Updates

To update the extension:

1. Download the latest version
2. Remove the old extension from `about:debugging`
3. Follow the installation steps again
4. Your watchlist data will be preserved

## 🆘 Support

If you encounter any issues:

1. Check the troubleshooting section above
2. Visit the project page: https://github.com/alienfacepalm/fitgirl-watcher
3. Check browser console for error messages (F12 → Console tab)

## 📄 License

This extension is provided as-is for educational and personal use.

---

**Enjoy managing your FitGirl repacks watchlist! 🎮**
