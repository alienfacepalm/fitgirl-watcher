# Installation Guide - Firefox

## 🎯 Visual Installation Steps

### Step 1: Open Extensions Page

**Firefox:**
1. Open Firefox browser
2. Type `about:debugging` in the address bar
3. Press Enter
4. Click "This Firefox" in the left sidebar

### Step 2: Enable Developer Mode

1. You should see "Load Temporary Add-on" button
2. This is already available in Firefox debugging mode

### Step 3: Install the Extension

1. Click the "Load Temporary Add-on" button
2. Navigate to this folder and select the manifest.json file
3. Click "Open"

### Step 4: Verify Installation

1. Look for "FitGirl Repacks Watchlist" in your extensions/add-ons list
2. Make sure it's enabled
3. You should see the extension icon in your browser toolbar

### Step 5: Test the Extension

1. Visit `https://fitgirl-repacks.site/`
2. You should see a purple top bar with "FitGirl Watchlist"
3. Look for "Add to Watchlist" buttons (➕) next to game items
4. Click the extension icon to open the popup

## 🎮 First Time Setup

### Setting Your Preferences

1. **Open Extension Popup**
   - Click the extension icon in your toolbar

2. **Go to Settings**
   - Click the "Settings" tab in the popup

3. **Configure Reminders**
   - Set your preferred reminder interval (default: 7 days)
   - Enable/disable desktop notifications

4. **Save Settings**
   - Your preferences are saved automatically

### Adding Your First Game

1. **Visit FitGirl Repacks**
   - Go to `https://fitgirl-repacks.site/`

2. **Find a Game**
   - Browse the available games
   - Look for the "Add to Watchlist" button (➕) next to game items

3. **Add to Watchlist**
   - Click the "Add to Watchlist" button
   - The button will change to "In Watchlist" (✅)

4. **Manage Your Watchlist**
   - Click the extension icon to view your watchlist
   - Use search and filter options to organize your games

## 🔧 Common Installation Issues

### "Load unpacked" Button Not Visible
- **Solution**: Make sure "Developer mode" is enabled
- **Chrome/Edge**: Toggle the switch in the top-right corner
- **Firefox**: This button should always be visible in debugging mode

### "This folder is not a valid extension"
- **Solution**: Make sure you selected the correct folder
- **Check**: The folder should contain manifest.json, background.js, content.js, etc.
- **Chrome/Edge**: Select the entire folder, not individual files
- **Firefox**: Select the manifest.json file specifically

### Extension Icon Not Appearing
- **Solution**: Check if the extension is enabled
- **Chrome/Edge**: Go to `chrome://extensions/` and ensure the toggle is on
- **Firefox**: Go to `about:debugging` and check the add-on status

### Extension Not Working on FitGirl Site
- **Solution**: Verify you're on the correct domain
- **Correct URL**: `https://fitgirl-repacks.site/`
- **Wrong URL**: `https://fit-girl.repacks/` (old domain)
- **Action**: Refresh the page after installing the extension

## 📱 Mobile Installation

**Note**: Browser extensions typically don't work on mobile browsers. This extension is designed for desktop browsers only.

## 🔄 Updating the Extension

### How to Update

1. **Download Latest Version**
   - Get the newest version from the project page

2. **Remove Old Extension**
   - Go to extensions page
   - Remove the old version

3. **Install New Version**
   - Follow the installation steps again
   - Your data will be preserved

### Data Preservation

- Your watchlist data is stored in your browser
- Updating the extension won't lose your data
- Data is tied to your browser profile

## 🆘 Need Help?

If you're still having trouble:

1. **Check Browser Console**
   - Press F12 to open developer tools
   - Look for error messages in the Console tab

2. **Verify File Structure**
   - Make sure all required files are present
   - Check that manifest.json is valid

3. **Try Different Method**
   - If "Load unpacked" doesn't work, try drag and drop
   - Restart your browser and try again

4. **Contact Support**
   - Visit the project page: https://github.com/alienfacepalm/fitgirl-watcher
   - Check for known issues and solutions

---

**Happy gaming! 🎮**
