# FitGirl Repacks Watchlist - Complete Release Package

**Version:** 2.0.2-20251006T035021  
**Release Date:** 2025-10-06  
**Author:** FitGirl Watchlist Team

## 📦 What's Included

This complete release package contains everything you need to install and use the FitGirl Repacks Watchlist extension:

### 🌐 Browser Extensions
- **chrome/** - Chrome extension files
- **edge/** - Microsoft Edge extension files
- **safari/** - Safari extension files
- **firefox/** - Firefox extension files

### 🛠️ Installation Tools
- **installers/** - Script-based installers for Windows, macOS, and Linux
- **native-installers/** - HTML-based installers that work in any browser

## 🚀 Quick Start

### Which file should I download? (TL;DR)

1) FitGirl Repacks Watchlist – Native Installers ZIP (Recommended)
- File: fitgirl-watchlist-{version}-{timestamp}-native-installers.zip
- Best for: Most users on Windows/macOS/Linux who want a zero-setup, double-click HTML installer that runs in the browser
- Why: Easiest path; no terminals or permissions needed. Just open the HTML and follow prompts

2) FitGirl Repacks Watchlist – Installers ZIP
- File: fitgirl-watchlist-{version}-{timestamp}-installers.zip
- Best for: Users who prefer script-based installers (.bat/.ps1/.sh) per OS
- Why: Works offline with platform-native scripts; still straightforward

3) FitGirl Repacks Watchlist – Chrome ZIP
- File: fitgirl-watchlist-{version}-{timestamp}-chrome.zip
- Best for: Manual install via chrome://extensions (Developer mode → Load unpacked)

4) FitGirl Repacks Watchlist – Edge ZIP
- File: fitgirl-watchlist-{version}-{timestamp}-edge.zip
- Best for: Manual install via edge://extensions (Developer mode → Load unpacked)

5) FitGirl Repacks Watchlist – Safari ZIP
- File: fitgirl-watchlist-{version}-{timestamp}-safari.zip
- Best for: Manual install via Safari Extension Builder

6) FitGirl Repacks Watchlist – Firefox XPI
- File: fitgirl-watchlist-{version}-{timestamp}-firefox.xpi
- Best for: Temporary load via about:debugging → Load Temporary Add-on

7) FitGirl Repacks Watchlist – Complete ZIP
- File: fitgirl-watchlist-{version}-{timestamp}-complete.zip
- Best for: Power users who want everything in one archive

### Option 1: Native HTML Installers (Recommended)
1. Go to the `native-installers/` folder
2. Double-click `chrome-installer.html` for Chrome/Edge
3. Double-click `firefox-installer.html` for Firefox
4. Follow the on-screen instructions

### Option 2: Script-based Installers
1. Go to the `installers/` folder
2. Choose your browser folder (`chrome/` or `firefox/`)
3. Run the appropriate installer for your OS:
   - **Windows**: Double-click `.bat` or `.ps1` files
   - **macOS/Linux**: Run `.sh` files in terminal

### Option 3: Manual Installation
1. **Chrome**: Go to `chrome://extensions/`, enable Developer mode, click "Load unpacked", select `chrome/` folder
2. **Edge**: Go to `edge://extensions/`, enable Developer mode, click "Load unpacked", select `edge/` folder
3. **Safari**: Go to Safari > Preferences > Advanced, enable "Show Develop menu", then Develop > Show Extension Builder, click "+" and select `safari/` folder
4. **Firefox**: Go to `about:debugging`, click "This Firefox", click "Load Temporary Add-on", select `firefox/manifest.json`

## 🎮 Features

- 🎯 **Easy Watchlist Management**: Add games to your watchlist with a single click
- ⏰ **Smart Reminders**: Set custom reminder intervals (default: 7 days)
- 🔔 **Desktop Notifications**: Get notified when it's time to check your watchlist
- 📱 **Modern UI**: Clean, responsive interface that works on all devices
- 💾 **Data Export/Import**: Backup and restore your watchlist data
- 🎯 **Smart Detection**: Automatically detects game items on fitgirl-repacks.site

## 📋 Installation Requirements

- **Chrome**: Version 88 or higher
- **Edge**: Version 88 or higher
- **Safari**: Version 14 or higher (macOS 11+)
- **Firefox**: Version 78 or higher
- **Website**: fitgirl-repacks.site

## 🔧 Troubleshooting

If you encounter any issues:

1. **Check the README files** in each folder for detailed instructions
2. **Verify your browser version** meets the requirements
3. **Make sure you're on the correct website** (fitgirl-repacks.site)
4. **Check browser console** for error messages (F12 → Console)

## 📞 Support

- **Project Page**: https://github.com/alienfacepalm/fitgirl-watcher
- **Issues**: Report problems on the project page
- **Documentation**: Check the README files in each folder

## 📄 License

This extension is provided as-is for educational and personal use.

---

**Enjoy managing your FitGirl repacks watchlist! 🎮**
