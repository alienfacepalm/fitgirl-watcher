# FitGirl Repacks Watchlist - Chrome/Edge Extension

## 🎮 About This Extension

A browser extension to create a watchlist for FitGirl repacks with reminder functionality

**Version:** 1.0.0  
**Author:** FitGirl Watchlist Team  
**Website:** https://github.com/alienfacepalm/fitgirl-watcher

## ✨ Features

- 🎯 **Easy Watchlist Management**: Add games to your watchlist with a single click
- ⏰ **Smart Reminders**: Set custom reminder intervals (default: 7 days)
- 🔔 **Desktop Notifications**: Get notified when it's time to check your watchlist
- 📱 **Modern UI**: Clean, responsive interface that works on all devices
- 💾 **Data Export/Import**: Backup and restore your watchlist data
- 🎯 **Smart Detection**: Automatically detects game items on fitgirl-repacks.site

## 🚀 Quick Installation

### Method 1: Load Unpacked (Recommended)

1. **Open Chrome/Edge Extensions Page**
   - Chrome: Go to `chrome://extensions/`
   - Edge: Go to `edge://extensions/`

2. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

3. **Load the Extension**
   - Click "Load unpacked" button
   - Select this folder (the one containing this README)
   - The extension should now appear in your extensions list

4. **Pin the Extension** (Optional)
   - Click the puzzle piece icon in the toolbar
   - Find "FitGirl Repacks Watchlist"
   - Click the pin icon to keep it visible

### Method 2: Drag and Drop

1. **Open Extensions Page**
   - Go to `chrome://extensions/` (Chrome) or `edge://extensions/` (Edge)

2. **Enable Developer Mode**
   - Toggle the "Developer mode" switch

3. **Drag and Drop**
   - Simply drag this entire folder onto the extensions page
   - The extension will be automatically installed

## 📋 Step-by-Step Installation Guide

### Step 1: Prepare Your Browser

1. Open Chrome or Microsoft Edge
2. Navigate to the extensions page:
   - **Chrome**: Type `chrome://extensions/` in the address bar
   - **Edge**: Type `edge://extensions/` in the address bar
3. Press Enter

### Step 2: Enable Developer Mode

1. Look for the "Developer mode" toggle in the top-right corner
2. Click the toggle to enable it
3. You should see additional buttons appear: "Load unpacked", "Pack extension", etc.

### Step 3: Install the Extension

1. Click the "Load unpacked" button
2. Navigate to and select this folder (the one containing manifest.json)
3. Click "Select Folder" or "Open"
4. The extension should now appear in your extensions list

### Step 4: Verify Installation

1. Look for "FitGirl Repacks Watchlist" in your extensions list
2. Make sure it's enabled (toggle should be blue/on)
3. You should see the extension icon in your browser toolbar

### Step 5: Test the Extension

1. Visit `https://fitgirl-repacks.site/`
2. You should see a purple top bar with "FitGirl Watchlist"
3. Look for "Add to Watchlist" buttons (➕) next to game items
4. Click the extension icon to open the popup and manage your watchlist

## 🎯 How to Use

### Adding Games to Watchlist

1. Visit any page on `fitgirl-repacks.site`
2. Look for the "Add to Watchlist" button (➕) next to game items
3. Click the button to add the game to your watchlist
4. The button will change to "In Watchlist" (✅) to confirm

### Managing Your Watchlist

1. Click the extension icon in your browser toolbar
2. View all your watchlisted games
3. Use the search and filter options to find specific games
4. Click on any game to visit its page
5. Remove games from your watchlist as needed

### Setting Reminders

1. Open the extension popup
2. Go to the "Settings" tab
3. Adjust the reminder interval (default: 7 days)
4. Enable/disable desktop notifications
5. Your settings will be saved automatically

## 🔧 Troubleshooting

### Extension Not Appearing

- **Check Developer Mode**: Make sure "Developer mode" is enabled
- **Refresh Extensions Page**: Reload the extensions page and try again
- **Check Folder**: Ensure you selected the correct folder containing manifest.json

### Extension Not Working on FitGirl

- **Check URL**: Make sure you're on `fitgirl-repacks.site` (not the old domain)
- **Refresh Page**: Try refreshing the page after installing the extension
- **Check Permissions**: Ensure the extension has permission to access the site

### Icons Not Showing

- **Check Icon Files**: Make sure icon16.png, icon48.png, and icon128.png exist in the icons/ folder
- **File Names**: Icon files must be named exactly as specified
- **File Format**: Icons must be in PNG format

### Notifications Not Working

- **Browser Settings**: Check that notifications are enabled in your browser settings
- **Extension Settings**: Make sure notifications are enabled in the extension settings
- **System Settings**: Ensure your operating system allows notifications from your browser

### Data Not Saving

- **Storage Permissions**: The extension needs storage permissions to save your watchlist
- **Browser Storage**: Check if your browser's storage is full or disabled
- **Private/Incognito Mode**: The extension may not work properly in private browsing mode

## 📁 File Structure

```
FitGirl Repacks Watchlist/
├── manifest.json          # Extension configuration
├── background.js          # Background service worker
├── content.js            # Content script for FitGirl pages
├── popup.html            # Extension popup interface
├── popup.js              # Popup functionality
├── popup.css             # Popup styling
├── styles.css            # Content script styling
├── icons/                # Extension icons
│   ├── icon16.png        # 16x16 icon
│   ├── icon48.png        # 48x48 icon
│   └── icon128.png       # 128x128 icon
├── README.md             # This file
├── INSTALLATION.md       # Detailed installation guide
└── TROUBLESHOOTING.md    # Troubleshooting guide
```

## 🔄 Updates

To update the extension:

1. Download the latest version
2. Remove the old extension from `chrome://extensions/`
3. Follow the installation steps again
4. Your watchlist data will be preserved

## 🆘 Support

If you encounter any issues:

1. Check the troubleshooting section above
2. Visit the project page: https://github.com/alienfacepalm/fitgirl-watcher
3. Check browser console for error messages (F12 → Console tab)

## 📄 License

This extension is provided as-is for educational and personal use.

---

**Enjoy managing your FitGirl repacks watchlist! 🎮**
