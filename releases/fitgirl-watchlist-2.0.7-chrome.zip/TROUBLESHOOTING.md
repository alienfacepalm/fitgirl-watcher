# Troubleshooting Guide

## 🚨 Common Issues and Solutions

### Extension Installation Issues

#### "Load unpacked" Button Not Visible
**Problem**: The "Load unpacked" button is not showing in the extensions page.

**Solutions**:
- **Chrome/Edge**: Enable "Developer mode" by toggling the switch in the top-right corner
- **Firefox**: Make sure you're on `about:debugging` and clicked "This Firefox"
- Refresh the extensions page and try again

#### "This folder is not a valid extension"
**Problem**: Browser says the folder is not a valid extension.

**Solutions**:
- **Chrome/Edge**: Select the entire folder containing manifest.json, not individual files
- **Firefox**: Select the manifest.json file specifically, not the folder
- Verify that manifest.json exists in the selected location
- Check that all required files are present (background.js, content.js, popup.html, etc.)

#### Extension Icon Not Appearing in Toolbar
**Problem**: The extension is installed but the icon doesn't show in the toolbar.

**Solutions**:
- Check if the extension is enabled in the extensions page
- Look for the extension in the extensions menu (puzzle piece icon)
- Pin the extension to the toolbar for easy access
- Restart your browser

### Extension Functionality Issues

#### Extension Not Working on FitGirl Site
**Problem**: The extension doesn't activate or show buttons on fitgirl-repacks.site.

**Solutions**:
- **Check URL**: Make sure you're on `https://fitgirl-repacks.site/` (not the old domain)
- **Refresh Page**: Reload the page after installing the extension
- **Check Permissions**: Ensure the extension has permission to access the site
- **Disable Other Extensions**: Try disabling other extensions that might conflict

#### "Add to Watchlist" Buttons Not Appearing
**Problem**: The purple top bar appears but no watchlist buttons are visible.

**Solutions**:
- **Wait for Page Load**: The buttons are added after the page fully loads
- **Check Page Structure**: The extension looks for specific HTML elements
- **Try Different Pages**: Test on different game pages
- **Refresh Page**: Reload the page and wait for buttons to appear

#### Watchlist Data Not Saving
**Problem**: Games added to watchlist disappear after refreshing.

**Solutions**:
- **Check Storage Permissions**: The extension needs storage permissions
- **Clear Browser Cache**: Clear your browser's cache and cookies
- **Check Private Mode**: The extension may not work in private/incognito mode
- **Disable Ad Blockers**: Some ad blockers interfere with extension storage

### Notification Issues

#### Desktop Notifications Not Working
**Problem**: No notifications appear when reminders are due.

**Solutions**:
- **Browser Settings**: Check that notifications are enabled in your browser settings
- **Extension Settings**: Make sure notifications are enabled in the extension popup
- **System Settings**: Ensure your operating system allows notifications from your browser
- **Check Notification Center**: Notifications might be going to your system's notification center

#### Reminders Not Triggering
**Problem**: Reminders are set but never appear.

**Solutions**:
- **Check Reminder Settings**: Verify the reminder interval is set correctly
- **Check Date/Time**: Ensure your system date and time are correct
- **Browser Background**: Make sure your browser is running (not closed)
- **Extension Status**: Verify the extension is still enabled and running

### Performance Issues

#### Extension Slowing Down Browser
**Problem**: Browser becomes slow after installing the extension.

**Solutions**:
- **Check Watchlist Size**: Large watchlists might impact performance
- **Clear Old Data**: Remove old or unused watchlist entries
- **Update Extension**: Make sure you're using the latest version
- **Restart Browser**: Close and reopen your browser

#### High Memory Usage
**Problem**: Extension uses too much memory.

**Solutions**:
- **Limit Watchlist Size**: Keep your watchlist under 100 items
- **Clear Browser Cache**: Clear your browser's cache regularly
- **Disable Unused Features**: Turn off notifications if not needed
- **Update Browser**: Make sure you're using the latest browser version

### Data Issues

#### Watchlist Data Lost
**Problem**: All watchlist data has disappeared.

**Solutions**:
- **Check Browser Profile**: Data is tied to your browser profile
- **Check Sync Settings**: If using browser sync, check sync status
- **Restore from Backup**: Use the export/import feature if you have backups
- **Check Storage**: Ensure your browser's storage isn't full

#### Import/Export Not Working
**Problem**: Can't export or import watchlist data.

**Solutions**:
- **Check File Format**: Import files must be in JSON format
- **Check File Size**: Large files might not import properly
- **Browser Permissions**: Ensure the browser can access downloaded files
- **Try Different Browser**: Test import/export in a different browser

### Browser-Specific Issues

#### Chrome/Edge Issues
**Problem**: Extension works differently in Chrome vs Edge.

**Solutions**:
- **Update Browser**: Make sure you're using the latest version
- **Check Extensions**: Disable other extensions that might conflict
- **Clear Data**: Clear browser data and reinstall extension
- **Check Permissions**: Verify all required permissions are granted

#### Firefox Issues
**Problem**: Extension doesn't work properly in Firefox.

**Solutions**:
- **Check Manifest Version**: Firefox uses Manifest V2, Chrome uses V3
- **Temporary Installation**: Remember that Firefox installations are temporary
- **Developer Edition**: Try Firefox Developer Edition for better extension support
- **Check about:config**: Verify Firefox settings allow extensions

## 🔍 Debugging Steps

### Enable Debug Mode

1. **Open Developer Tools**
   - Press F12 or right-click → "Inspect"

2. **Check Console Tab**
   - Look for error messages
   - Note any red error text

3. **Check Network Tab**
   - Verify that extension files are loading
   - Look for failed requests

### Check Extension Status

1. **Go to Extensions Page**
   - Chrome/Edge: `chrome://extensions/`
   - Firefox: `about:debugging`

2. **Check Extension Details**
   - Verify it's enabled
   - Check for error messages
   - Look at permissions

3. **Test on Different Pages**
   - Try the extension on different FitGirl pages
   - Test with different browsers

### Collect Information for Support

If you need help, collect this information:

1. **Browser Information**
   - Browser name and version
   - Operating system
   - Extension version

2. **Error Messages**
   - Screenshots of any error messages
   - Console error logs
   - Steps to reproduce the issue

3. **Extension Status**
   - Whether extension is enabled
   - Any error messages in extensions page
   - Watchlist size and settings

## 🆘 Getting Help

### Self-Help Resources

1. **Check This Guide**: Review all sections above
2. **Project Documentation**: Visit https://github.com/alienfacepalm/fitgirl-watcher
3. **Browser Help**: Check your browser's extension documentation

### Contact Support

1. **Project Issues**: Report bugs on the project page
2. **Browser Support**: Contact your browser's support team
3. **Community Forums**: Ask for help in relevant communities

### Before Asking for Help

Please try these steps first:

1. ✅ Restart your browser
2. ✅ Clear browser cache and cookies
3. ✅ Disable other extensions temporarily
4. ✅ Try the extension in a different browser
5. ✅ Check that you're on the correct website (fitgirl-repacks.site)

---

**Most issues can be resolved by following the solutions above. If you're still having trouble, don't hesitate to ask for help! 🆘**
